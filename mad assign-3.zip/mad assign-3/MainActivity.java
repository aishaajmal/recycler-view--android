package com.example.myapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ProductAdapter adapter;
    List<Product> productList;
    TextView totalText;
    EditText search;
    ImageView sortBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        totalText = findViewById(R.id.totalText);
        search = findViewById(R.id.searchInput);
        sortBtn = findViewById(R.id.sortButton);

        productList = ProductDatabase.getDemoProducts();
        adapter = new ProductAdapter(this, productList, this::calculateTotal);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        calculateTotal();

        search.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String q = s.toString().toLowerCase();
                List<Product> filtered = new ArrayList<>();
                for (Product p : ProductDatabase.getDemoProducts()) {
                    if (p.name.toLowerCase().contains(q)) filtered.add(p);
                }
                productList.clear();
                productList.addAll(filtered);
                adapter.notifyDataSetChanged();
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void afterTextChanged(Editable s) {}
        });

        sortBtn.setOnClickListener(v -> {
            Collections.sort(productList, Comparator.comparingDouble(p -> p.price));
            adapter.notifyDataSetChanged();
        });
    }

    void calculateTotal() {
        double total = 0;
        for (Product p : productList) total += p.price * p.quantity;
        totalText.setText("Total: $" + String.format("%.2f", total));
    }
}
