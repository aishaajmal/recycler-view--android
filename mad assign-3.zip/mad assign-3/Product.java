package com.example.myapplication;

import java.io.Serializable;

public class Product implements Serializable {
    public int id;
    public String name;
    public String description;
    public double price;
    public int imageResId;
    public int quantity;

    public Product(int id, String name, String description, double price, int imageResId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResId = imageResId;
        this.quantity = 0;
    }
}
