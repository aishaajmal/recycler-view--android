package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    Context context;
    List<Product> products;
    OnCartChangeListener listener;

    public interface OnCartChangeListener {
        void onCartChanged();
    }

    public ProductAdapter(Context context, List<Product> products, OnCartChangeListener listener) {
        this.context = context;
        this.products = products;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product p = products.get(position);
        holder.name.setText(p.name);
        holder.desc.setText(p.description);
        holder.price.setText("$" + p.price);
        holder.image.setImageResource(p.imageResId);
        holder.qty.setText(String.valueOf(p.quantity));

        holder.add.setOnClickListener(v -> {
            p.quantity++;
            holder.qty.setText(String.valueOf(p.quantity));
            listener.onCartChanged();
        });
        holder.remove.setOnClickListener(v -> {
            if (p.quantity > 0) {
                p.quantity--;
                holder.qty.setText(String.valueOf(p.quantity));
                listener.onCartChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView name, desc, price, qty;
        Button add, remove;
        ImageView image;

        public ProductViewHolder(@NonNull View v) {
            super(v);
            name = v.findViewById(R.id.productName);
            desc = v.findViewById(R.id.productDescription);
            price = v.findViewById(R.id.productPrice);
            qty = v.findViewById(R.id.quantity);
            add = v.findViewById(R.id.btnAdd);
            remove = v.findViewById(R.id.btnRemove);
            image = v.findViewById(R.id.productImage);
        }
    }
}
