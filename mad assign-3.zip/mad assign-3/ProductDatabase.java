package com.example.myapplication;

import java.util.ArrayList;
import java.util.List;

public class ProductDatabase {
    public static List<Product> getDemoProducts() {
        List<Product> list = new ArrayList<>();
        list.add(new Product(1, "T-Shirt", "Soft cotton shirt", 165.99, R.drawable.shirt_icon));
        list.add(new Product(2, "Sneakers", "Sporty running shoes", 99.99, R.drawable.shirt_icon));
        list.add(new Product(3, "Hoodie", "Warm hoodie", 89.49, R.drawable.shirt_icon));
        list.add(new Product(4, "Jeans", "Slim fit jeans", 120.00, R.drawable.shirt_icon));
        return list;
    }
}
